The dataset is included in the file and the paths should all be set up.
The code was written in Jupyter Notebooks.
All you should have to do is run all the cells in order.
The versions I am using are listed below.
A few of the code cells may take up to 23 minutes depending on your hardware.
If you have any issues running the code, please don't hesitate to email me at mgrimmett@albany.edu

Thank you so much!


Python                   3.8.5
pip                      21.1.1
scipy                    1.4.1
matplotlib               3.4.1
numpy                    1.18.5
scikit-image             0.18.1
scikit-learn             0.24.2
opencv-python            4.5.1.48
Pillow                   7.2.0
jupyter-client           6.1.6
jupyter-core             4.6.3
jupyterlab               2.2.6
jupyterlab-server        1.2.0
ipykernel                5.3.4
ipython                  7.17.0
ipython-genutils         0.2.0